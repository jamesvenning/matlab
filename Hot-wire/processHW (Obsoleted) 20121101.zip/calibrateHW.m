function [] = calibrateHW()


% Check the inputs
if ~exist( 'fs', 'var' )
	[fs d] = uigetfile( '.txt', 'MultiSelect', 'on' );
end

if ischar(fs), fs={fs}; end

% Declare constants
blockSize	= 4096;			% Samples per block
in2pa		= 248.8;		% Conversion factor [Pa/in.H2O]
rho			= 1.225;		% Density of air [kg/m3]
k			= 1.05;			% Tunnel calibration constant, see Little 2010 p.33

% Loop through each file
nFiles = length(fs);
for n=1:nFiles
	% Load the data
	ff	= fullfile( d, fs{n} );
	data = load( ff );
	
	M = size( data, 1 )/blockSize;
	
	% Deal out the data
	V		= data(:,1);
	Po		= data(1:M,2)*in2pa;
	Pinf	= data(1:M,3)*in2pa;
	
	% Store the mean and rms values
	Vm(n)	= mean( V );
	Vrms(n) = std( V );
	
	Qm		= k*mean( Po + Pinf );
	Qrms	= k*std( Po ) + k*std( Pinf );
	
	Um(n)	= sqrt( 2*Qm/rho );
	Urms(n) = sqrt( 2*Qrms/rho );
end

% Perform least-squares fit of King's Law to data
eq		= @(c,x) c(1)+c(2)*x.^c(3);
coef	= lsqcurvefit( eq, [1 1 1], Vm, Um );

% Plot the results for reference
figure;
errorbar( Vm, Um, Urms, '+k' ); hold on;
herrorbar( Vm, Um, Vrms, '+k' );
plot( Vm, eq(coef,Vm), '-k' ); hold off;
xlabel('Voltage, V [V]'); ylabel('Velocity, U [m/s]');

% Save the calibration
fout = fullfile( d, 'calibration.mat' );
save( fout, 'Vm','Vrms', 'Um','Urms', 'eq','coef' );