function [] = processHW( fs, d )


% Check the inputs
if ~exist( 'fs', 'var' )
	[fs d] = uigetfile( '.txt', 'MultiSelect', 'on' );
end

if ischar(fs), fs={fs}; end

% Load the calibration file
calFile = fullfile( d, 'calibration.mat' );
if ~exist( calFile, 'file' )
	error( 'You must run calibrateHW first!' );
else
	cal = load( calFile );
end

% Declare constants
blockSize	= 4096;			% Samples per block
in2pa		= 248.8;		% Conversion factor [Pa/in.H2O]

%
nFiles = length(fs);

% Preallocate matrices
Um		= zeros( 1, nFiles );
Urms	= zeros( 1, nFiles );
X		= zeros( 1, nFiles );
Y		= zeros( 1, nFiles );

% Loop through each file
for n=1:nFiles
	% Load the data
	ff = fullfile( d, fs{n} );
	data = load(ff);
	
	M = size( data, 1 )/blockSize;
	
	% Get the voltage and convert to velocity
	V = data(:,1);
	U = cal.eq( cal.coef, V );			% Black box approach
	
	% Store the mean and rms values
	Um(n)	= mean( U );
	Urms(n)	= std( U );
	
	% Get (x,y) coordinates in the format '_x[x]_y[y]'
	expr = ['_x(?<x>[0-9\.\-]+)' ...		% Find '_x#.#' and return '#.#'
		'_y(?<y>[0-9\.\-]+)'];				% Find '_y#.#' and return '#.#'
	s = regexpi( fs{n}, expr, 'names' );
	X(n) = str2double( s.x );
	Y(n) = str2double( s.y );
end

%
Po		= mean( data(1:M,2) )*in2pa;
Pinf	= mean( data(1:M,3) )*in2pa;
Pamb	= mean( data(1:M,4) );
Tinf	= mean( data(1:M,5) );
Tamb	= mean( data(1:M,6) );

% Make sure values are properly ordered (assumes a y-axis sweep)
[Y i]	= sort(Y);
X		= X(i);
Um		= Um(i);
Urms	= Urms(i);

% Prepare outputs
out.X		= measurement( 'Streamwise Coordinate', 'x', 'mm', X );
out.Y		= measurement( 'Vertical Coordinate', 'y', 'mm', Y );

out.Um		= measurement( 'Streamwise Velocity', 'u', 'm/s', Um );
out.Urms	= measurement( 'RMS of Streamwise Velocity', 'u_{rms}', 'm/s', Urms );

out.Po		= measurement( 'Stagnation Pressure', 'p_o', 'Pa', Po );
out.Pinf	= measurement( 'Freestream Pressure', '-p_\infty', 'Pa', Pinf );
out.Pamb	= measurement( 'Ambient Pressure', 'p_{amb}', 'Pa', Pamb );

out.Tinf	= measurement( 'Stagnation Temperature', 'T_\infty', 'K', Tinf );
out.Tamb	= measurement( 'Ambient Temperature', 'T_{amb}', 'K', Tamb );

% Save the results
ff = regexprep( fs{1}, '_x[0-9\.\-]+_y[0-9\.\-]+_[0-9]+.txt', '.mat' );
save( ff, '-struct', 'out' );